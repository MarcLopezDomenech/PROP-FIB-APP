var searchData=
[
  ['testvalues_542',['testValues',['../classtest_1_1domain_1_1documents_1_1_test_documents_set.html#af6c6babe87e807502d1681559032c28c',1,'test.domain.documents.TestDocumentsSet.testValues()'],['../classtest_1_1domain_1_1expressions_1_1_test_expressions_set.html#a8c7f22d05592c62d61b374965c6a0bf0',1,'test.domain.expressions.TestExpressionsSet.testValues()']]],
  ['title_543',['title',['../classmain_1_1domain_1_1documents_1_1_document.html#a22cdf90d611fb5a4dcbc20d766fb6c75',1,'main::domain::documents::Document']]],
  ['totalwords_544',['totalWords',['../classmain_1_1domain_1_1documents_1_1_internal_document.html#a4b7355febdfa8f7d9b122d3074bfe02a',1,'main::domain::documents::InternalDocument']]]
];
