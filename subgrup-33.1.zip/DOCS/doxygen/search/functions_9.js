var searchData=
[
  ['listall_411',['listAll',['../classmain_1_1domain_1_1documents_1_1_documents_set.html#af703d330fde17f472051fde96842cab2',1,'main::domain::documents::DocumentsSet']]],
  ['listalldocuments_412',['listAllDocuments',['../classmain_1_1domain_1_1_ctrl_domain.html#a6cebf7cfcbd826d2e231a60f9ae523ed',1,'main::domain::CtrlDomain']]],
  ['listauthorsbyprefix_413',['listAuthorsByPrefix',['../classmain_1_1domain_1_1_ctrl_domain.html#a3f90f9e65e3aa3dfe968fbce703e99da',1,'main.domain.CtrlDomain.listAuthorsByPrefix()'],['../classmain_1_1domain_1_1documents_1_1_documents_set.html#ada888d43367248968b5986188a69af33',1,'main.domain.documents.DocumentsSet.listAuthorsByPrefix()']]],
  ['listbyexpression_414',['listByExpression',['../classmain_1_1domain_1_1_ctrl_domain.html#a5e49ea0d0baf93b0c16d74771a04d166',1,'main.domain.CtrlDomain.listByExpression()'],['../classmain_1_1domain_1_1documents_1_1_documents_set.html#aeebc8a3491f925e09032139feb2a9827',1,'main.domain.documents.DocumentsSet.listByExpression()']]],
  ['listbyquery_415',['listByQuery',['../classmain_1_1domain_1_1_ctrl_domain.html#aa57ed4bd06eb0a8b284a81ad6b1fc144',1,'main.domain.CtrlDomain.listByQuery()'],['../classmain_1_1domain_1_1documents_1_1_documents_set.html#a4f65368dfe6c788961a2841fb1eed3d4',1,'main.domain.documents.DocumentsSet.listByQuery()']]],
  ['listsimilars_416',['listSimilars',['../classmain_1_1domain_1_1_ctrl_domain.html#afb44ee87e327980137b94a90b59acd66',1,'main.domain.CtrlDomain.listSimilars()'],['../classmain_1_1domain_1_1documents_1_1_documents_set.html#adcd3768ba2f3c997da54c873394890fc',1,'main.domain.documents.DocumentsSet.listSimilars()']]],
  ['listtitlesofauthor_417',['listTitlesOfAuthor',['../classmain_1_1domain_1_1_ctrl_domain.html#a56f149998243fea98476649a228ef53b',1,'main.domain.CtrlDomain.listTitlesOfAuthor()'],['../classmain_1_1domain_1_1documents_1_1_documents_set.html#a44c23820e6d19e3eacf41a3bbae2bf16',1,'main.domain.documents.DocumentsSet.listTitlesOfAuthor()']]],
  ['literal_418',['Literal',['../classmain_1_1domain_1_1expressions_1_1_literal.html#ad04ca19ae3580cd2cd3e0f7f8d966b8e',1,'main::domain::expressions::Literal']]]
];
