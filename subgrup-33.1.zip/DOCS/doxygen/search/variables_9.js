var searchData=
[
  ['presence_534',['presence',['../classmain_1_1domain_1_1documents_1_1_documents_set.html#ad2a6783df94e8f627e935d004df658ad',1,'main.domain.documents.DocumentsSet.presence()'],['../classtest_1_1domain_1_1documents_1_1_test_document.html#a521093ad9d4d398cffea28da12366eed',1,'test.domain.documents.TestDocument.presence()']]]
];
