var searchData=
[
  ['second_154',['second',['../classmain_1_1domain_1_1util_1_1_pair.html#a0d8ffa6d65e63c0361d166048f619d4d',1,'main::domain::util::Pair']]],
  ['setcontent_155',['setContent',['../classmain_1_1domain_1_1documents_1_1_document.html#ae2307f660f64188e4aaaf53ed8564ea2',1,'main.domain.documents.Document.setContent()'],['../classtest_1_1domain_1_1documents_1_1_document.html#a62a8dc76b6ff20f9b40b8719ed900d6d',1,'test.domain.documents.Document.setContent()']]],
  ['setdocuments_156',['setDocuments',['../classmain_1_1domain_1_1documents_1_1_documents_set.html#ad67c12c0a7d069e62cd43cff012b1707',1,'main::domain::documents::DocumentsSet']]],
  ['setexpressions_157',['setExpressions',['../classmain_1_1domain_1_1expressions_1_1_expressions_set.html#ade9539427c682cc7e47e54dd58b3d2c7',1,'main::domain::expressions::ExpressionsSet']]],
  ['setfirst_158',['setFirst',['../classmain_1_1domain_1_1util_1_1_pair.html#a8d5472c2cd9e170821c8fcdc8613f39b',1,'main::domain::util::Pair']]],
  ['setlanguage_159',['setLanguage',['../classmain_1_1domain_1_1documents_1_1_document.html#a87a036a33d420080e3cd8f2ee6254544',1,'main.domain.documents.Document.setLanguage()'],['../classtest_1_1domain_1_1documents_1_1_document.html#a215d1b2a81d61d60f8bdea9e546b6f13',1,'test.domain.documents.Document.setLanguage()']]],
  ['setsecond_160',['setSecond',['../classmain_1_1domain_1_1util_1_1_pair.html#ad378fa8e0633b678509439fc297de591',1,'main::domain::util::Pair']]],
  ['simpleand_161',['simpleAnd',['../classtest_1_1domain_1_1expressions_1_1_test_expression.html#abe2fbee9172e4170f4eaaee82d140335',1,'test::domain::expressions::TestExpression']]],
  ['simplenot_162',['simpleNot',['../classtest_1_1domain_1_1expressions_1_1_test_expression.html#a5adece107319766c21328a85196ef23a',1,'test::domain::expressions::TestExpression']]],
  ['simpleor_163',['simpleOr',['../classtest_1_1domain_1_1expressions_1_1_test_expression.html#a0e55b4acbd05a22d283647e54ad7949a',1,'test::domain::expressions::TestExpression']]],
  ['singletonobject_164',['singletonObject',['../classmain_1_1domain_1_1_ctrl_domain.html#a29bf0158aaf32bd4f43934feef7a82d3',1,'main.domain.CtrlDomain.singletonObject()'],['../classmain_1_1domain_1_1documents_1_1_documents_set.html#aec4d056831339fb06ea4e1ebfd0a8547',1,'main.domain.documents.DocumentsSet.singletonObject()'],['../classmain_1_1domain_1_1expressions_1_1_expressions_set.html#aded374b0e1e762acb925f37624dca1ad',1,'main.domain.expressions.ExpressionsSet.singletonObject()']]],
  ['stopwords_5fca_165',['stopWords_ca',['../classmain_1_1domain_1_1documents_1_1_internal_document.html#a44d94784ad6ce3c34ca9f100825ceb3a',1,'main::domain::documents::InternalDocument']]],
  ['stopwords_5fen_166',['stopWords_en',['../classmain_1_1domain_1_1documents_1_1_internal_document.html#a688c0ff85ef7540403959f6d88007f65',1,'main::domain::documents::InternalDocument']]],
  ['stopwords_5fes_167',['stopWords_es',['../classmain_1_1domain_1_1documents_1_1_internal_document.html#a3a56b47b90a20787da03c87676c91fdb',1,'main::domain::documents::InternalDocument']]]
];
