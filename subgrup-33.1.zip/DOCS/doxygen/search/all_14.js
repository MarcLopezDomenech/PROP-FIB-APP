var searchData=
[
  ['writebackup_260',['writeBackUp',['../classmain_1_1domain_1_1documents_1_1_internal_document.html#ad6c6dec47d91876ee3e26f6846d36c6a',1,'main::domain::documents::InternalDocument']]]
];
