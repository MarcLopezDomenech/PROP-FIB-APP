var searchData=
[
  ['author_519',['author',['../classmain_1_1domain_1_1documents_1_1_document.html#a9d07984230a1c5d4b9201d24d3f459ba',1,'main::domain::documents::Document']]]
];
