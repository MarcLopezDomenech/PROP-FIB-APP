var searchData=
[
  ['originalformat_533',['originalFormat',['../classmain_1_1domain_1_1documents_1_1_document.html#a42827cc3ff13e51cd450a0d1b52efd78',1,'main::domain::documents::Document']]]
];
