var searchData=
[
  ['language_529',['language',['../classmain_1_1domain_1_1documents_1_1_document.html#ae6d7ccb2cbad67c22ed6702ea2f425f2',1,'main.domain.documents.Document.language()'],['../classtest_1_1domain_1_1documents_1_1_document.html#acc2338d01f9f4b2bbd584bd8079f674d',1,'test.domain.documents.Document.language()']]],
  ['left_530',['left',['../classmain_1_1domain_1_1expressions_1_1_and.html#acd8867f8bed20cd7ea1ec1b2b8ddfeff',1,'main.domain.expressions.And.left()'],['../classmain_1_1domain_1_1expressions_1_1_or.html#ab4727836a091f632c215bcf4fb1df329',1,'main.domain.expressions.Or.left()']]]
];
