var searchData=
[
  ['num_5fdocs_531',['num_docs',['../classtest_1_1domain_1_1documents_1_1_test_document.html#acbc9f5add7b57c937dd915c78ff9c841',1,'test::domain::documents::TestDocument']]],
  ['numdocuments_532',['numDocuments',['../classmain_1_1domain_1_1documents_1_1_documents_set.html#ab46c724a53fe004dc506e33159d33a2d',1,'main::domain::documents::DocumentsSet']]]
];
