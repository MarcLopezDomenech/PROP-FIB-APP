# PROJECTES DE PROGRAMACIO 33.1 

Entorn per a la manipulació i edició de documents txt i xml

--- 

**AUTHORS**
- Cortés Danés, Ariadna :yum:
- Duran Manzano, Pau :blush:
- López Domènech, Marc :sunglasses:
- Valls Camps, Marc :innocent:  
 
ariadna.cortes.danes@estudiantat.upc.edu   
pau.duran.manzano@estudiantat.upc.edu   
marc.lopez.domenech@estudiantat.upc.edu   
marc.valls.camps@estudiantat.upc.edu   
