var searchData=
[
  ['helpdialog_519',['HelpDialog',['../classmain_1_1presentation_1_1_help_dialog.html#a26b1109c25f6101542f72fbf5176e49e',1,'main::presentation::HelpDialog']]]
];
