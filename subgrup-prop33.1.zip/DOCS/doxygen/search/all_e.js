var searchData=
[
  ['pair_241',['Pair',['../classmain_1_1domain_1_1util_1_1_pair.html',1,'main.domain.util.Pair&lt; F, S &gt;'],['../classmain_1_1domain_1_1util_1_1_pair.html#a9dfe968acf6c0afdf66e9d1a71c5165d',1,'main.domain.util.Pair.Pair()'],['../classmain_1_1domain_1_1util_1_1_pair.html#aa032e4a9892300f4d7e2d7331d93b6d8',1,'main.domain.util.Pair.Pair(F first, S second)']]],
  ['pair_2ejava_242',['Pair.java',['../_pair_8java.html',1,'']]],
  ['pair_3c_20string_2c_20boolean_20_3e_243',['Pair&lt; String, Boolean &gt;',['../classmain_1_1domain_1_1util_1_1_pair.html',1,'main::domain::util']]],
  ['pair_3c_20string_2c_20integer_20_3e_244',['Pair&lt; String, Integer &gt;',['../classmain_1_1domain_1_1util_1_1_pair.html',1,'main::domain::util']]],
  ['pair_3c_20string_2c_20string_20_3e_245',['Pair&lt; String, String &gt;',['../classmain_1_1domain_1_1util_1_1_pair.html',1,'main::domain::util']]],
  ['panel_246',['panel',['../classmain_1_1presentation_1_1_expressions_view.html#a211b5761943e6925375e0718cd188132',1,'main.presentation.ExpressionsView.panel()'],['../classmain_1_1presentation_1_1_main_view.html#aea92c61a4dcc45d2f0f64a43231c1994',1,'main.presentation.MainView.panel()']]],
  ['parser_247',['Parser',['../classmain_1_1persistence_1_1_parser.html',1,'main.persistence.Parser'],['../classmain_1_1persistence_1_1_parser.html#aa13dc3c65d72ac436bf51abbc840dbe1',1,'main.persistence.Parser.Parser()']]],
  ['parser_2ejava_248',['Parser.java',['../_parser_8java.html',1,'']]],
  ['path_249',['path',['../classmain_1_1presentation_1_1_downloader_dialog.html#aa3b8916770d8abf9610e3edf04090450',1,'main.presentation.DownloaderDialog.path()'],['../classmain_1_1presentation_1_1_loader_dialog.html#abf840286cc5e3f4b2ea444fc1980d800',1,'main.presentation.LoaderDialog.path()']]],
  ['presence_250',['presence',['../classmain_1_1domain_1_1documents_1_1_documents_set.html#ad2a6783df94e8f627e935d004df658ad',1,'main::domain::documents::DocumentsSet']]]
];
