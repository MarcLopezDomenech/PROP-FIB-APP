var searchData=
[
  ['relevantwords_694',['relevantWords',['../classmain_1_1domain_1_1documents_1_1_internal_document.html#a61f07a967b0c76d53bfb7d09054cf457',1,'main::domain::documents::InternalDocument']]],
  ['reset_695',['reset',['../classmain_1_1presentation_1_1_expressions_view.html#aa0791079966b0be4198ac224910951b2',1,'main.presentation.ExpressionsView.reset()'],['../classmain_1_1presentation_1_1_main_view.html#afe31a33cb7432660b2fcdfca75d3249f',1,'main.presentation.MainView.reset()']]],
  ['result_696',['result',['../classmain_1_1presentation_1_1_list_author_dialog.html#a1c89795d41febc6557684e9d55fb3ece',1,'main.presentation.ListAuthorDialog.result()'],['../classmain_1_1presentation_1_1_list_expression_dialog.html#ac48c207e01300aac30fe2a0c3d9f3099',1,'main.presentation.ListExpressionDialog.result()'],['../classmain_1_1presentation_1_1_list_query_dialog.html#a5e434e55d2b65d7fd63af6f2d3b04654',1,'main.presentation.ListQueryDialog.result()'],['../classmain_1_1presentation_1_1_modify_dialog.html#a21c85c741ae4be08133081bc3bb9b114',1,'main.presentation.ModifyDialog.result()']]],
  ['right_697',['right',['../classmain_1_1domain_1_1expressions_1_1_and.html#ac84a4a73cbe3d121944c641795610cb1',1,'main.domain.expressions.And.right()'],['../classmain_1_1domain_1_1expressions_1_1_or.html#a59c49f3b51b94e3c3ccf6f616cb2a29c',1,'main.domain.expressions.Or.right()']]],
  ['root_698',['root',['../classmain_1_1domain_1_1util_1_1_trie.html#a03f628a7fe5a2732fe84b22347c74e77',1,'main::domain::util::Trie']]]
];
