var searchData=
[
  ['main_373',['Main',['../classmain_1_1presentation_1_1_main.html',1,'main::presentation']]],
  ['mainview_374',['MainView',['../classmain_1_1presentation_1_1_main_view.html',1,'main::presentation']]],
  ['modifydialog_375',['ModifyDialog',['../classmain_1_1presentation_1_1_modify_dialog.html',1,'main::presentation']]]
];
