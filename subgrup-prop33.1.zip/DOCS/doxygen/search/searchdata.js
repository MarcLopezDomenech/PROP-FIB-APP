var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwx",
  1: "acdefhilmnoptx",
  2: "m",
  3: "acdefhilmnoptx",
  4: "acdefghiklmnopqrstuwx",
  5: "abcdefhiklmnopqrstv",
  6: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Namespaces",
  3: "Fitxers",
  4: "Funcions",
  5: "Variables",
  6: "Pàgines"
};

