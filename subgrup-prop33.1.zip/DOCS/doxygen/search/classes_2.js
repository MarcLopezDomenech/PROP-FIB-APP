var searchData=
[
  ['document_343',['Document',['../classmain_1_1domain_1_1documents_1_1_document.html',1,'main::domain::documents']]],
  ['documentsset_344',['DocumentsSet',['../classmain_1_1domain_1_1documents_1_1_documents_set.html',1,'main::domain::documents']]],
  ['downloaderdialog_345',['DownloaderDialog',['../classmain_1_1presentation_1_1_downloader_dialog.html',1,'main::presentation']]]
];
