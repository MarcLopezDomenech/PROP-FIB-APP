var searchData=
[
  ['name_683',['name',['../classmain_1_1presentation_1_1_downloader_dialog.html#ab7bf6a12add0d881abe463915ae4f4bf',1,'main::presentation::DownloaderDialog']]],
  ['nofav_684',['nofav',['../classmain_1_1presentation_1_1_fav_check_box.html#aa9feb590a4abc89c0b90e5834f7df345',1,'main::presentation::FavCheckBox']]],
  ['numdocuments_685',['numDocuments',['../classmain_1_1domain_1_1documents_1_1_documents_set.html#ab46c724a53fe004dc506e33159d33a2d',1,'main::domain::documents::DocumentsSet']]]
];
