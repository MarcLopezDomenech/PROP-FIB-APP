var searchData=
[
  ['okpressed_686',['okPressed',['../classmain_1_1presentation_1_1_downloader_dialog.html#a646416e3840306d4dc0dc8a6684eef87',1,'main.presentation.DownloaderDialog.okPressed()'],['../classmain_1_1presentation_1_1_list_k_similars_dialog.html#a61556831710f52feabe054e6dae77132',1,'main.presentation.ListKSimilarsDialog.okPressed()'],['../classmain_1_1presentation_1_1_loader_dialog.html#a757e8da011ee28cbcd3d71a0b10206fd',1,'main.presentation.LoaderDialog.okPressed()'],['../classmain_1_1presentation_1_1_new_document_dialog.html#aa52979407f5f79d56ec5d3f4f51d74ca',1,'main.presentation.NewDocumentDialog.okPressed()']]],
  ['originalformat_687',['originalFormat',['../classmain_1_1domain_1_1documents_1_1_document.html#a42827cc3ff13e51cd450a0d1b52efd78',1,'main::domain::documents::Document']]]
];
