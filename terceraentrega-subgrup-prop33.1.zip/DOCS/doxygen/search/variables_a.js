var searchData=
[
  ['menubar_676',['menubar',['../classmain_1_1presentation_1_1_main_view.html#ae19d579d8c9d78267783d1b1a1c76b07',1,'main::presentation::MainView']]],
  ['menubar_677',['menuBar',['../classmain_1_1presentation_1_1_expressions_view.html#a7eb5dd1237030cbb7f82e5fa15086d11',1,'main::presentation::ExpressionsView']]],
  ['menulist_678',['menuList',['../classmain_1_1presentation_1_1_main_view.html#a19924086d4a117456a1ecee3a24bf571',1,'main::presentation::MainView']]],
  ['menuoptions_679',['menuOptions',['../classmain_1_1presentation_1_1_expressions_view.html#ae28bce9ecfa04b2ed51ae010ab3820e2',1,'main.presentation.ExpressionsView.menuOptions()'],['../classmain_1_1presentation_1_1_main_view.html#af3c349549830c55d35f14533dc03c113',1,'main.presentation.MainView.menuOptions()']]],
  ['message_680',['message',['../classmain_1_1presentation_1_1_error_dialog.html#aa8736b4109ed2ef675306b7a1f706c3c',1,'main.presentation.ErrorDialog.message()'],['../classmain_1_1presentation_1_1_help_dialog.html#a57fdfb98043a7cded5d1300c2316ad29',1,'main.presentation.HelpDialog.message()']]],
  ['mod_681',['mod',['../classmain_1_1presentation_1_1_list_author_dialog.html#a419799d0edb249dc500ec7a325b6b597',1,'main::presentation::ListAuthorDialog']]],
  ['modify_682',['modify',['../classmain_1_1presentation_1_1_expressions_view.html#a56694584a34b61dc87e86a97cd1b1ba9',1,'main.presentation.ExpressionsView.modify()'],['../classmain_1_1presentation_1_1_main_view.html#ab3a5438b4858b26f5253b09bb492699f',1,'main.presentation.MainView.modify()'],['../classmain_1_1presentation_1_1_modify_dialog.html#a68a4669d2f5c48170f25ac48243a12db',1,'main.presentation.ModifyDialog.modify()']]]
];
