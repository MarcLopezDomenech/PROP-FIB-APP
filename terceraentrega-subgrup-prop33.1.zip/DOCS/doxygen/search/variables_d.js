var searchData=
[
  ['panel_688',['panel',['../classmain_1_1presentation_1_1_expressions_view.html#a211b5761943e6925375e0718cd188132',1,'main.presentation.ExpressionsView.panel()'],['../classmain_1_1presentation_1_1_main_view.html#aea92c61a4dcc45d2f0f64a43231c1994',1,'main.presentation.MainView.panel()']]],
  ['path_689',['path',['../classmain_1_1presentation_1_1_downloader_dialog.html#aa3b8916770d8abf9610e3edf04090450',1,'main.presentation.DownloaderDialog.path()'],['../classmain_1_1presentation_1_1_loader_dialog.html#abf840286cc5e3f4b2ea444fc1980d800',1,'main.presentation.LoaderDialog.path()']]],
  ['presence_690',['presence',['../classmain_1_1domain_1_1documents_1_1_documents_set.html#ad2a6783df94e8f627e935d004df658ad',1,'main::domain::documents::DocumentsSet']]]
];
