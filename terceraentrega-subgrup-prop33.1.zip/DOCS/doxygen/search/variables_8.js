var searchData=
[
  ['k_660',['k',['../classmain_1_1presentation_1_1_list_k_similars_dialog.html#a92099e189e0fa1cf89951349c56cda9e',1,'main.presentation.ListKSimilarsDialog.k()'],['../classmain_1_1presentation_1_1_list_query_dialog.html#aeff9cac069d787997acb74f127ba5880',1,'main.presentation.ListQueryDialog.k()']]]
];
