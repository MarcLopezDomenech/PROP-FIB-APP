var searchData=
[
  ['main_543',['main',['../classmain_1_1presentation_1_1_main.html#a00c1ffbce9f4bf6206a179d661d6fee8',1,'main::presentation::Main']]],
  ['mainview_544',['MainView',['../classmain_1_1presentation_1_1_main_view.html#a3db939e4ad74d0b2c1c09a1ee4223ed3',1,'main::presentation::MainView']]],
  ['modifydialog_545',['ModifyDialog',['../classmain_1_1presentation_1_1_modify_dialog.html#a3c2c934dbe5c38444ae8650b65eeb094',1,'main::presentation::ModifyDialog']]],
  ['modifyexpression_546',['modifyExpression',['../classmain_1_1domain_1_1_ctrl_domain.html#a8e29a29caaa5e0ba058c122802496b58',1,'main.domain.CtrlDomain.modifyExpression()'],['../classmain_1_1presentation_1_1_ctrl_presentation.html#a7704c2bfa4ec519165ed8d48b4268e2a',1,'main.presentation.CtrlPresentation.modifyExpression()']]]
];
