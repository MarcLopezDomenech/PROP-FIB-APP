var searchData=
[
  ['queryrelevance_559',['queryRelevance',['../classmain_1_1domain_1_1documents_1_1_document.html#a4141d702712f878fb1370d5cf14cd110',1,'main::domain::documents::Document']]]
];
