var searchData=
[
  ['quer_691',['quer',['../classmain_1_1presentation_1_1_list_query_dialog.html#ac0f0422b860ff876d2b3bb6445a1af9d',1,'main::presentation::ListQueryDialog']]],
  ['query_692',['query',['../classmain_1_1presentation_1_1_list_query_dialog.html#ae814a2af0d15205e0dcad28bce28e7a2',1,'main::presentation::ListQueryDialog']]],
  ['query_5ftext_693',['query_text',['../classmain_1_1presentation_1_1_list_query_dialog.html#ab005d4a4040bf96dfaeca4831304b61f',1,'main::presentation::ListQueryDialog']]]
];
