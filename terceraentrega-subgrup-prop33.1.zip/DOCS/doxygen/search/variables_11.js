var searchData=
[
  ['text_709',['text',['../classmain_1_1presentation_1_1_confirm_dialog.html#ac893e016fbbaf7c88eb525eb40126b05',1,'main.presentation.ConfirmDialog.text()'],['../classmain_1_1presentation_1_1_expressions_modify_dialog.html#aff7f336c4d9ce07a3cb23b4b074b0a15',1,'main.presentation.ExpressionsModifyDialog.text()'],['../classmain_1_1presentation_1_1_expressions_view.html#a6e8124ef0528d76c0ad28368353df8f5',1,'main.presentation.ExpressionsView.text()']]],
  ['text_5faut_710',['text_aut',['../classmain_1_1presentation_1_1_list_author_dialog.html#af14851f83294b9e267d8443d17d89bd5',1,'main::presentation::ListAuthorDialog']]],
  ['textcont_711',['textcont',['../classmain_1_1presentation_1_1_modify_dialog.html#a34c5018ae7c9cb52a288b3d9cedd2d2d',1,'main::presentation::ModifyDialog']]],
  ['tfboolean_712',['tfBoolean',['../classmain_1_1presentation_1_1_list_k_similars_dialog.html#a955f5f9d761011968ed02db96b679b7b',1,'main::presentation::ListKSimilarsDialog']]],
  ['tfidf_713',['tfIdf',['../classmain_1_1presentation_1_1_list_k_similars_dialog.html#a49a13980c70be3ac2903c2988757bb8c',1,'main::presentation::ListKSimilarsDialog']]],
  ['timesword_714',['timesWord',['../classmain_1_1domain_1_1util_1_1_trie_1_1_node.html#a8c8bdbac194b715bf002e1e09117d457',1,'main::domain::util::Trie::Node']]],
  ['tit_715',['tit',['../classmain_1_1presentation_1_1_modify_dialog.html#a33600b13fbacee96103bf982467bb23f',1,'main::presentation::ModifyDialog']]],
  ['tit_5ffield_716',['tit_field',['../classmain_1_1presentation_1_1_modify_dialog.html#ae73ffe63e8a572952f9d49fe895847d6',1,'main::presentation::ModifyDialog']]],
  ['title_717',['title',['../classmain_1_1domain_1_1documents_1_1_document.html#a22cdf90d611fb5a4dcbc20d766fb6c75',1,'main::domain::documents::Document']]],
  ['titledoc_718',['titleDoc',['../classmain_1_1presentation_1_1_downloader_dialog.html#a13e7eb0d69220a91c502d37ac3154ec1',1,'main.presentation.DownloaderDialog.titleDoc()'],['../classmain_1_1presentation_1_1_list_k_similars_dialog.html#ab7c1e78daa39f6cbad6a187287ca9cd2',1,'main.presentation.ListKSimilarsDialog.titleDoc()'],['../classmain_1_1presentation_1_1_new_document_dialog.html#aa784a14eaeae891e864eab998defef87',1,'main.presentation.NewDocumentDialog.titleDoc()']]],
  ['totalwords_719',['totalWords',['../classmain_1_1domain_1_1documents_1_1_internal_document.html#aef2647d4f0776ea79eca2e21cb3d01da',1,'main::domain::documents::InternalDocument']]]
];
