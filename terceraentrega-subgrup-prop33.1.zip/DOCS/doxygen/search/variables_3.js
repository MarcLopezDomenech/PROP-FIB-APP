var searchData=
[
  ['delete_637',['delete',['../classmain_1_1presentation_1_1_expressions_view.html#a8428012ffec25169021850317ba5d15b',1,'main.presentation.ExpressionsView.delete()'],['../classmain_1_1presentation_1_1_main_view.html#a19740996d486327d1fa1a58d3e35d71f',1,'main.presentation.MainView.delete()']]],
  ['descendants_638',['descendants',['../classmain_1_1domain_1_1util_1_1_trie_1_1_node.html#ad5fd96fab216f32d28982fc06176686c',1,'main::domain::util::Trie::Node']]],
  ['documents_639',['documents',['../classmain_1_1domain_1_1documents_1_1_documents_set.html#a73499eb2c98f088a8aabe117fa31d018',1,'main.domain.documents.DocumentsSet.documents()'],['../classmain_1_1presentation_1_1_main_view.html#a0f41b26c7e5c04146c88f2dcb31a2b97',1,'main.presentation.MainView.documents()']]],
  ['documentsmodel_640',['documentsModel',['../classmain_1_1presentation_1_1_main_view.html#ab453725d59a2314b0a46ea835c2aa053',1,'main::presentation::MainView']]],
  ['ds_641',['ds',['../classmain_1_1domain_1_1_ctrl_domain.html#a3187d8c3e4425be67508cf5534447bed',1,'main::domain::CtrlDomain']]]
];
