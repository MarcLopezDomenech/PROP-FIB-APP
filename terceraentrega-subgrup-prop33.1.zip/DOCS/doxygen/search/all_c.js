var searchData=
[
  ['name_223',['name',['../classmain_1_1presentation_1_1_downloader_dialog.html#ab7bf6a12add0d881abe463915ae4f4bf',1,'main::presentation::DownloaderDialog']]],
  ['newcontent_224',['newContent',['../classmain_1_1domain_1_1documents_1_1_internal_document.html#a9f91c869997baab29b340d42f97ce11b',1,'main::domain::documents::InternalDocument']]],
  ['newdocumentdialog_225',['NewDocumentDialog',['../classmain_1_1presentation_1_1_new_document_dialog.html',1,'main.presentation.NewDocumentDialog'],['../classmain_1_1presentation_1_1_new_document_dialog.html#a59eb3f158ed803be1fa38e5fc77d2936',1,'main.presentation.NewDocumentDialog.NewDocumentDialog()']]],
  ['newdocumentdialog_2ejava_226',['NewDocumentDialog.java',['../_new_document_dialog_8java.html',1,'']]],
  ['node_227',['Node',['../classmain_1_1domain_1_1util_1_1_trie_1_1_node.html',1,'main.domain.util.Trie.Node'],['../classmain_1_1domain_1_1util_1_1_trie_1_1_node.html#aa95b68f3b434f34c49f7c65585a72e72',1,'main.domain.util.Trie.Node.Node()']]],
  ['nofav_228',['nofav',['../classmain_1_1presentation_1_1_fav_check_box.html#aa9feb590a4abc89c0b90e5834f7df345',1,'main::presentation::FavCheckBox']]],
  ['not_229',['Not',['../classmain_1_1domain_1_1expressions_1_1_not.html',1,'main.domain.expressions.Not'],['../classmain_1_1domain_1_1expressions_1_1_not.html#a9b8ab28cd8ed08079f8ddbb8df63b602',1,'main.domain.expressions.Not.Not()']]],
  ['not_2ejava_230',['Not.java',['../_not_8java.html',1,'']]],
  ['numdocuments_231',['numDocuments',['../classmain_1_1domain_1_1documents_1_1_documents_set.html#ab46c724a53fe004dc506e33159d33a2d',1,'main::domain::documents::DocumentsSet']]]
];
